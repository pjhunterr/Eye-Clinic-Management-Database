<?php
require_once('mysqli_connect.php');
session_start();

if (!isset($_SESSION['login_user'])) {
    echo "<p><b>Error:</b> User not logged in.</p>";
    exit();
}

$patient_ID = $_SESSION['login_user'];

function generateID($prefix, $length = 9) {
    return $prefix . substr(str_shuffle("0123456789"), 0, $length - strlen($prefix));
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['item_ID'])) {
    $original_item_ID = $_POST['item_ID'];
    $quantity = isset($_POST['quantity'][$original_item_ID]) ? (int)$_POST['quantity'][$original_item_ID] : 0;

    // Get item details
    $query = "SELECT * FROM Items WHERE item_ID = '$original_item_ID'";
    $result = mysqli_query($dbc, $query);

    if ($result && mysqli_num_rows($result) > 0) {
        $item = mysqli_fetch_assoc($result);

        if ($quantity < 1 || $item['qtyInStock'] < $quantity) {
            echo "<p><b>Error:</b> Invalid quantity or not enough stock available.</p>";
        } else {
            $order_ID = generateID("ORD");
            $new_item_ID = generateID("ITM");
            $totalAmount = $item['salePrice'] * $quantity;
            $orderDate = date('Y-m-d');

            // Insert into Orders table
            $insertOrder = "INSERT INTO Orders (patient_ID, totalAmount, orderDate, order_ID)
                            VALUES ('$patient_ID', $totalAmount, '$orderDate', '$order_ID')";
            $orderResult = mysqli_query($dbc, $insertOrder);

            // Update qtyInStock for the original item
            $newStock = $item['qtyInStock'] - $quantity;
            $updateStock = "UPDATE Items SET qtyInStock = $newStock WHERE item_ID = '$original_item_ID'";
            mysqli_query($dbc, $updateStock);

            // Insert purchased item as a new row with new item_ID
            $insertItem = "INSERT INTO Items (productType, qtyInStock, itemName, item_ID, salePrice, order_ID)
                           VALUES ('{$item['productType']}', $quantity, '{$item['itemName']}', '$new_item_ID', {$item['salePrice']}, '$order_ID')";
            $itemResult = mysqli_query($dbc, $insertItem);

            if ($orderResult && $itemResult) {
                echo "<p><b>Success!</b> Your order has been placed. Order ID: $order_ID</p>";
            } else {
                echo "<p><b>Error:</b> Failed to place order. " . mysqli_error($dbc) . "</p>";
            }
        }
    } else {
        echo "<p><b>Error:</b> Item not found.</p>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Make an Order</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
<h2>Available Eye Care Items</h2>
<form method="post">
    <table border="1" cellpadding="10">
        <tr>
            <th>Select</th>
            <th>Item Name</th>
            <th>Type</th>
            <th>Price ($)</th>
            <th>In Stock</th>
            <th>Quantity</th>
        </tr>
        <?php
        $itemsQuery = "SELECT * FROM Items WHERE qtyInStock > 0 GROUP BY item_ID";
        $itemsResult = mysqli_query($dbc, $itemsQuery);

        if ($itemsResult && mysqli_num_rows($itemsResult) > 0) {
            while ($row = mysqli_fetch_assoc($itemsResult)) {
                echo "<tr>";
                echo "<td><input type='radio' name='item_ID' value='{$row['item_ID']}' required></td>";
                echo "<td>{$row['itemName']}</td>";
                echo "<td>{$row['productType']}</td>";
                echo "<td>{$row['salePrice']}</td>";
                echo "<td>{$row['qtyInStock']}</td>";
                echo "<td><input type='number' name='quantity[{$row['item_ID']}]' min='1' max='{$row['qtyInStock']}'></td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='6'>No items available for order.</td></tr>";
        }
        ?>
    </table>
    <br>
    <input type="submit" value="Place Order">
</form>

<p><a href="index.php">Home</a></p>
</body>
</html>
