<?php
// Code for logout.php
   session_start();
   
   if(session_destroy()) {
      header("Location: patientLogin.php");
   }
?>
