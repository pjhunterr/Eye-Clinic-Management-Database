<-- addCustomers.php ->
<!DOCTYPE html>
<!
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link rel="stylesheet" type="text/css" href="styles.css">
    </head>
    <body>                    
        <?php
        echo "<p><a href=\"index.php\">Home</a></p>";
        echo "<br />";
        echo "<div class='container'>";
        echo "<h2>Patient Registration</h2>";
        echo "<form action=\"patientAdded.php\" method=\"POST\">";
        echo "<label for='patient_ID'>Patient ID:</label>";
        echo "<input type='text' name='patient_ID' id='patient_ID' size='10' />";
        echo "<label for='name'>Name:</label>";
        echo "<input type='text' name='name' id='name' size='30' />";
        echo "<label for='ssn'>SSN:</label>";
        echo "<input type='text' name='ssn' id='ssn' size='10' />";
        echo "<label for='password'>Password:</label>";
        echo "<input type='password' name='password' id='password' size='20' />";
        echo "<label for='gender'>Gender:</label>";
        echo "<input type='text' name='gender' id='gender' size='1' maxlength='1' />";
        echo "<label for='dateOfBirth'>Date of Birth:</label>";
        echo "<input type='date' name='dateOfBirth' id='dateOfBirth' />";
        echo "<label for='medHistory'>Medical History:</label>";
        echo "<input type='text' name='medHistory' id='medHistory' size='50' />";
        echo "<label for='address'>Address:</label>";
        echo "<input type='text' name='address' id='address' size='40' />";
        echo "<label for='phoneNumber'>Phone Number:</label>";
        echo "<input type='text' name='phoneNumber' id='phoneNumber' size='15' />";
        echo "<label for='email'>Email:</label>";
        echo "<input type='email' name='email' id='email' size='30' />";
        echo "<label for='contactMethod'>Preferred Contact Method:</label>";
        echo "<input type='text' name='contactMethod' id='contactMethod' size='20' />";
        echo "<p><input type='submit' name='submit' value='Register' /></p>";
        echo "</form>";
        echo "</div>";
                
        ?>
    </body>
</html>
