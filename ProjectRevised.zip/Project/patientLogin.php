<?php
   require_once('mysqli_connect.php');
   session_start(); // to start the session
   
   if($_SERVER["REQUEST_METHOD"] == "POST") {
      // username and password sent from form 
      
      $mypatient_ID = mysqli_real_escape_string($dbc,$_POST['patient_ID']);
      $mypassword = mysqli_real_escape_string($dbc,$_POST['password']); 
     // echo "user name $mypatient_ID <br>";
      $sql = "SELECT patient_ID FROM Patient WHERE patient_ID = '".$mypatient_ID."' and password = '".$mypassword."'";
      $response = mysqli_query($dbc,$sql);
      $row = mysqli_fetch_array($response,MYSQLI_ASSOC);
      
      $count = mysqli_num_rows($response);
      
      // If response matched $mypatient_ID and $mypassword, table row must be 1 row		
      if($count == 1) {
        // session_register("mypatient_ID");
         $_SESSION['login_user'] = $mypatient_ID;
         
         header("location: patientWelcome.php");
      }else {
         $error = "Your Login Name or Password is invalid";
      }
   }
?>

<html>
   
   <head>
      <title>Patient Login Page</title>
      <link rel="stylesheet" type="text/css" href="styles.css">

      
   </head>
   
   <body bgcolor = "#FFFFFF">
	
      <div align = "center">
         <div style = "width:300px; border: solid 1px #333333; " align = "left">
            <div style = "background-color:#333333; color:#FFFFFF; padding:3px;"><b>Login</b></div>			
            <div style = "margin:30px">
               
                <form action = "" method = "POST">
                  <label>Patient ID  :  </label><input type = 'text' name = 'patient_ID' /><br /><br />
                  <label>Password  :  </label><input type = 'password' name = 'password'  /><br/><br />
                  <input type = 'submit' value = 'Submit'/><br />
               </form>				
            </div>			
         </div>		
      </div>
   </body>
</html>
