<?php
   require_once('mysqli_connect.php');
   session_start(); // to start the session
   
   if($_SERVER["REQUEST_METHOD"] == "POST") {
      // username and password sent from form 
      
      $mydocID = mysqli_real_escape_string($dbc,$_POST['docID']);
      $mypassword = mysqli_real_escape_string($dbc,$_POST['password']); 
     // echo "user name $mydocID <br>";
      $sql = "SELECT docID FROM DoctorWork WHERE docID = '".$mydocID."' and password = '".$mypassword."'";
      $response = mysqli_query($dbc,$sql);
      $row = mysqli_fetch_array($response,MYSQLI_ASSOC);
      
      $count = mysqli_num_rows($response);
      
      // If response matched $mydocID and $mypassword, table row must be 1 row		
      if($count == 1) {
        // session_register("mydocID");
         $_SESSION['login_user'] = $mydocID;
         
         header("location: doctorWelcome.php");
      }else {
         $error = "Your Login Name or Password is invalid";
      }
   }
?>

<html>
   
   <head>
      <title>Doctor Login Page</title>
      <link rel="stylesheet" type="text/css" href="styles.css">

      
   </head>
   
   <body bgcolor = "#FFFFFF">
	
      <div align = "center">
         <div style = "width:300px; border: solid 1px #333333; " align = "left">
            <div style = "background-color:#333333; color:#FFFFFF; padding:3px;"><b>Login</b></div>			
            <div style = "margin:30px">
               
                <form action = "" method = "POST">
                  <label>Doctor ID  :  </label><input type = 'text' name = 'docID' /><br /><br />
                  <label>Password  :  </label><input type = 'password' name = 'password'  /><br/><br />
                  <input type = 'submit' value = 'Submit'/><br />
               </form>				
            </div>			
         </div>		
      </div>
   </body>
</html>
