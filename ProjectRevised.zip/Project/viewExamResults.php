<?php
require_once('mysqli_connect.php');
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>View Exam Results</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
<?php
if (!isset($_SESSION['login_user'])) {
    echo "<p><b>Error:</b> User not logged in.</p>";
    exit();
}

$patient_ID = $_SESSION['login_user'];  // Patient's ID from session

// Query to retrieve the exam results for the logged-in patient
$query = "
    SELECT r.exam_ID, r.testResults, r.date AS resultDate, r.notes, r.prescription, r.diagnosis, a.date AS appointmentDate
    FROM Results r
    JOIN Exam e ON r.exam_ID = e.exam_ID
    JOIN DoctorWork d ON e.docID = d.docID  -- Join DoctorWork using docID
    JOIN AppointmentSchedule a ON d.appID = a.appID  -- Join AppointmentSchedule using appID from DoctorWork
    WHERE e.patient_ID = 'P12345678'
    AND a.date < CURDATE()  -- Only completed appointments
    AND r.testResults IS NOT NULL  -- Only results that are available
    ORDER BY r.date DESC;

";

$response = mysqli_query($dbc, $query);

if (!$response) {
    echo "<p><b>Error:</b> Could not retrieve exam results. " . mysqli_error($dbc) . "</p>";
} elseif (mysqli_num_rows($response) > 0) {
    echo "<h2>Your Exam Results</h2>";
    echo "<table border='1' cellpadding='10'>";
    echo "<tr><th>Exam ID</th><th>Test Results</th><th>Result Date</th><th>Notes</th><th>Prescription</th><th>Diagnosis</th><th>Appointment Date</th></tr>";

    // Loop through the results and display them
    
    while ($row = mysqli_fetch_array($response, MYSQLI_ASSOC)) {
        echo "<tr>";
        echo "<td>{$row['exam_ID']}</td>";
        echo "<td>{$row['testResults']}</td>";
        echo "<td>{$row['resultDate']}</td>";
        echo "<td>{$row['notes']}</td>";
        echo "<td>{$row['prescription']}</td>";
        echo "<td>{$row['diagnosis']}</td>";
        echo "<td>{$row['appointmentDate']}</td>";
        echo "</tr>";
    }

    echo "</table>";
} else {
    echo "<p>You have no completed appointments or exam results available.</p>";
}

echo "<p><a href='patientWelcome.php'>Home</a></p>";
?>
</body>
</html>
