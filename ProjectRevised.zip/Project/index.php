

<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Project</title>
        <link rel="stylesheet" type="text/css" href="styles.css">
    </head>
    <body>
        <h1>Eye Clinic Portal</h1>
        
        <?php
        echo "<p><a href=\"patientRegistration.php\">Patient Registration</a></p>";
        echo "<p><a href=\"doctorRegistration.php\">Doctor Registration</a></p>";
		echo "<p><a href=\"patientLogin.php\">Patient Login</a></p>";
        echo "<p><a href=\"doctorLogin.php\">Doctor Login</a></p>";
        ?>

    </body>
</html>
