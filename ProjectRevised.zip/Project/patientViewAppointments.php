<?php
require_once('mysqli_connect.php');
session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Your Appointments</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
<?php
if (!isset($_SESSION['login_user'])) {
    echo "<p><b>Error:</b> User not logged in.</p>";
    exit();
}

$patient_ID = $_SESSION['login_user'];

// If form was submitted to update appointment time
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['updateTime'])) {
    $appID = $_POST['appID'];
    $newDate = $_POST['newDate'];
    $newTime = $_POST['newTime'];
    $newDateTime = $newDate . ' ' . $newTime . ':00';

    $updateQuery = "UPDATE AppointmentSchedule SET date = '$newDate', time = '$newDateTime' 
                    WHERE appID = '$appID' AND patient_ID = '$patient_ID'";
    
    $updateResult = mysqli_query($dbc, $updateQuery);

    if ($updateResult && mysqli_affected_rows($dbc) > 0) {
        echo "<p style='color:green;'>Appointment updated successfully.</p>";
    } else {
        echo "<p style='color:red;'>Failed to update appointment or no changes made.</p>";
    }
}

$query = "SELECT appID, date, time FROM AppointmentSchedule 
          WHERE patient_ID = '$patient_ID' ORDER BY date, time";
$response = mysqli_query($dbc, $query);

if (!$response) {
    echo "<p><b>Error:</b> Could not retrieve appointments. " . mysqli_error($dbc) . "</p>";
} elseif (mysqli_num_rows($response) > 0) {
    echo "<h2>Your Upcoming Appointments</h2>";
    echo "<table border='1' cellpadding='10'>";
    echo "<tr><th>Appointment ID</th><th>Date</th><th>Time</th><th>Update Appointment</th></tr>";
    
    while ($row = mysqli_fetch_array($response, MYSQLI_ASSOC)) {
        $currentDate = $row['date'];
        $currentTime = date('H:i', strtotime($row['time'])); // Extract just time portion
        echo "<tr>";
        echo "<form method='POST'>";
        echo "<td>{$row['appID']}<input type='hidden' name='appID' value='{$row['appID']}'></td>";
        echo "<td><input type='date' name='newDate' value='$currentDate' required></td>";
        echo "<td><input type='time' name='newTime' value='$currentTime' required></td>";
        echo "<td><input type='submit' name='updateTime' value='Update'></td>";
        echo "</form>";
        echo "</tr>";
    }
    
    echo "</table>";
} else {
    echo "<p>You have no appointments scheduled.</p>";
}

echo "<p><a href='index.php'>Home</a></p>";
?>
</body>
</html>
