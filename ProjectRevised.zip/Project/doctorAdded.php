<!-- Code for doctorAdded.php -->
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Doctor Added</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>

<?php
if (isset($_POST['submit'])) {
    $data_missing = array();

    // Expected fields
    $fields = ['docID', 'name', 'email', 'password'];

    foreach ($fields as $field) {
        if (empty($_POST[$field])) {
            $data_missing[] = $field;
        } else {
            $$field = trim($_POST[$field]); // Dynamic variable assignment
        }
    }

    if (empty($data_missing)) {
        require_once('mysqli_connect.php');

        $query = "INSERT INTO DoctorWork (docID, name, email, password, appID)
                  VALUES (?, ?, ?, ?, ?)";

        $stmt = mysqli_prepare($dbc, $query);
        mysqli_stmt_bind_param($stmt, "sssss", $docID, $name, $email, $password, $appID);
        mysqli_stmt_execute($stmt);

        if (mysqli_stmt_affected_rows($stmt) == 1) {
            echo "Doctor successfully added.<br>";
            echo "Doctor Name: " . htmlspecialchars($name);
        } else {
            echo "Error occurred while adding doctor.<br>";
            echo mysqli_error($dbc);
        }

        mysqli_stmt_close($stmt);
        mysqli_close($dbc);
    } else {
        echo "The following data is missing:<br>";
        foreach ($data_missing as $missing) {
            echo htmlspecialchars($missing) . "<br>";
        }
    }
}
?>

<p><a href="index.php">Home</a></p>

</body>
</html>
