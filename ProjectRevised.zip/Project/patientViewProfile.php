<!-- viewProfile.php -->
<?php
require_once('mysqli_connect.php');
session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Your Profile</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
<?php
    if (isset($_SESSION['login_user'])) {
        $patientID = mysqli_real_escape_string($dbc, $_SESSION['login_user']);

        // Query to fetch patient data by patient_ID
        $query = "SELECT * FROM Patient WHERE patient_ID = '$patientID'";
        $response = mysqli_query($dbc, $query);

        if ($response && mysqli_num_rows($response) == 1) {
            $row = mysqli_fetch_array($response, MYSQLI_ASSOC);

            echo "<h2>Patient Profile</h2>";
            echo "<p>Patient ID: {$row['patient_ID']}</p>";
            echo "<p>Name: {$row['name']}</p>";
            echo "<p>Gender: {$row['gender']}</p>";
            echo "<p>Date of Birth: {$row['dateOfBirth']}</p>";
            echo "<p>Medical History: {$row['medHistory']}</p>";
            echo "<p>Address: {$row['address']}</p>";
            echo "<p>Phone Number: {$row['phoneNumber']}</p>";
            echo "<p>Email: {$row['email']}</p>";
            echo "<p>Preferred Contact Method: {$row['contactMethod']}</p>";
            echo "<p><a href='patientWelcome.php'>Home</a></p>";
        } else {
            echo "<p><b>Error:</b> Invalid patient ID or user not found.</p>";
        }
    } else {
        echo "<p><b>Error:</b> User not logged in.</p>";
    }
?>
</body>
</html>
