<?php
require_once('mysqli_connect.php');
session_start();
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Your Appointments</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
<?php
    if (isset($_SESSION['login_user'])) {
        $doctorID = mysqli_real_escape_string($dbc, $_SESSION['login_user']);

        // Query to get the doctor's assigned appointments based on docID
        $query = "
            SELECT a.appID, a.date, a.time, p.name AS patientName, p.patient_ID
            FROM AppointmentSchedule a
            JOIN DoctorWork d ON a.appID = d.appID
            JOIN Patient p ON a.patient_ID = p.patient_ID
            WHERE d.docID = '$doctorID'
            ORDER BY a.date, a.time
        ";
        $response = mysqli_query($dbc, $query);

        if ($response && mysqli_num_rows($response) > 0) {
            echo "<h2>Your Assigned Appointments</h2>";
            echo "<table border='1' cellpadding='10'>";
            echo "<tr><th>Appointment ID</th><th>Patient Name</th><th>Appointment Date</th><th>Appointment Time</th></tr>";

            while ($row = mysqli_fetch_array($response, MYSQLI_ASSOC)) {
                echo "<tr>";
                echo "<td>{$row['appID']}</td>";
                echo "<td>{$row['patientName']}</td>";
                echo "<td>{$row['date']}</td>";
                echo "<td>{$row['time']}</td>";
                echo "</tr>";
            }

            echo "</table>";
        } else {
            echo "<p>You have no appointments assigned.</p>";
        }
    } else {
        echo "<p><b>Error:</b> User not logged in.</p>";
    }

    echo "<p><a href='doctorWelcome.php'>Home</a></p>";
?>
</body>
</html>
