<?php
// Code for welcome.php
require_once('session.php');

echo "<p> <h1>Welcome  $docLogin_session </h1></p>";

echo "<p><a href = \"doctorLogout.php\">Sign Out</a></p>";
echo "<p><a href=\"doctorViewProfile.php\">View Your Profile</a></p>";
echo "<p><a href=\"doctorViewAppointments.php\">View Your Appointments</a></p>";
echo "<p><a href=\"writeExamResults.php\">Enter Exam Results</a></p>";




?>

