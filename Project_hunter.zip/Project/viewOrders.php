<?php
require_once('mysqli_connect.php');
session_start();

if (!isset($_SESSION['login_user'])) {
    echo "<p><b>Error:</b> User not logged in.</p>";
    exit();
}

$patient_ID = $_SESSION['login_user'];
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Your Orders</title>
</head>
<body>
<h2>Your Past Orders</h2>

<?php
// Fetch orders made by the patient
$orderQuery = "SELECT * FROM Orders WHERE patient_ID = '$patient_ID' ORDER BY orderDate DESC";
$orderResult = mysqli_query($dbc, $orderQuery);

if ($orderResult && mysqli_num_rows($orderResult) > 0) {
    while ($order = mysqli_fetch_assoc($orderResult)) {
        $order_ID = $order['order_ID'];
        echo "<h3>Order ID: {$order_ID} | Date: {$order['orderDate']} | Total: \${$order['totalAmount']}</h3>";

        // Fetch items for this order
        $itemQuery = "SELECT * FROM Items WHERE order_ID = '$order_ID'";
        $itemResult = mysqli_query($dbc, $itemQuery);

        if ($itemResult && mysqli_num_rows($itemResult) > 0) {
            echo "<table border='1' cellpadding='8'>";
            echo "<tr>
                    <th>Item Name</th>
                    <th>Product Type</th>
                    <th>Quantity Ordered</th>
                    <th>Price ($)</th>
                  </tr>";

            while ($item = mysqli_fetch_assoc($itemResult)) {
                echo "<tr>";
                echo "<td>{$item['itemName']}</td>";
                echo "<td>{$item['productType']}</td>";
                echo "<td>{$item['qtyInStock']}</td>";
                echo "<td>{$item['salePrice']}</td>";
                echo "</tr>";
            }

            echo "</table><br>";
        } else {
            echo "<p>No items found for this order.</p>";
        }
    }
} else {
    echo "<p>You have not placed any orders yet.</p>";
}
?>

<p><a href="index.php">Home</a></p>
</body>
</html>
