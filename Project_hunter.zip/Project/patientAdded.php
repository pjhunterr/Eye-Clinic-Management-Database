<!-- Code for PatientAdded.php -->
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Patient Added</title>
</head>
<body>

<?php
if (isset($_POST['submit'])) {
    $data_missing = array();

    // Required fields based on the DB table
    $fields = [
        'patient_ID', 'ssn', 'password', 'gender', 'dateOfBirth', 'medHistory',
        'address', 'phoneNumber', 'email', 'name', 'contactMethod'
    ];

    foreach ($fields as $field) {
        if (empty($_POST[$field])) {
            $data_missing[] = $field;
        } else {
            $$field = trim($_POST[$field]); // Variable variable, e.g., $patient_ID
        }
    }

    if (empty($data_missing)) {
        require_once('mysqli_connect.php');

        $query = "INSERT INTO Patient 
            (patient_ID, ssn, password, gender, dateOfBirth, medHistory, address, phoneNumber, email, name, contactMethod)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        $stmt = mysqli_prepare($dbc, $query);

        mysqli_stmt_bind_param($stmt, "sssssssssss", 
            $patient_ID, $ssn, $password, $gender, $dateOfBirth, $medHistory, 
            $address, $phoneNumber, $email, $name, $contactMethod);

        mysqli_stmt_execute($stmt);

        if (mysqli_stmt_affected_rows($stmt) == 1) {
            echo 'Patient successfully entered.<br>';
            echo "Patient Name: " . htmlspecialchars($name);
        } else {
            echo 'Error occurred.<br>';
            echo mysqli_error($dbc);
        }

        mysqli_stmt_close($stmt);
        mysqli_close($dbc);

    } else {
        echo 'You need to enter the following data:<br />';
        foreach ($data_missing as $missing) {
            echo htmlspecialchars($missing) . "<br />";
        }
    }
}
?>

<p><a href="index.php">Home</a></p>

</body>
</html>
