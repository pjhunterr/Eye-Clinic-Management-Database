<?php
// Code for welcome.php
require_once('session.php');

echo "<p> <h1>Welcome  $login_session </h1></p>";

echo "<p><a href = \"patientLogout.php\">Sign Out</a></p>";
echo "<p><a href=\"patientViewProfile.php\">View Your Profile</a></p>";
echo "<p><a href=\"patientUpdateProfile.php\">Update Your Profile</a></p>";
echo "<p><a href=\"patientViewAppointments.php\">View Appointments</a></p>";
echo "<p><a href=\"scheduleAppointment.php\">Schedule Appointment</a></p>";
echo "<p><a href=\"billPayment.php\">Bill Payment Information</a></p>";
echo "<p><a href=\"makeOrder.php\">Place Order</a></p>";
echo "<p><a href=\"viewOrders.php\">View Order</a></p>";
echo "<p><a href=\"viewExamResults.php\">View Exam Results</a></p>";

?>

