<?php
require_once('mysqli_connect.php');
session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Update Your Profile</title>
</head>
<body>
<?php
if (!isset($_SESSION['login_user'])) {
    echo "<p><b>Error:</b> User not logged in.</p>";
    exit();
}

$patient_ID = $_SESSION['login_user'];

$query = "SELECT * FROM Patient WHERE patient_ID = '$patient_ID'";
$response = mysqli_query($dbc, $query);
$row = mysqli_fetch_array($response, MYSQLI_ASSOC);

if (mysqli_num_rows($response) == 1) {
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $name = $_POST['name'];
        $address = $_POST['address'];
        $phoneNumber = $_POST['phoneNumber'];
        $email = $_POST['email'];
        $password = $_POST['password'];
        $medHistory = $_POST['medHistory'];
        $contactMethod = $_POST['contactMethod'];

        $updateQuery = "UPDATE Patient SET 
                        name = '$name',
                        address = '$address',
                        phoneNumber = '$phoneNumber',
                        email = '$email',
                        password = '$password',
                        medHistory = '$medHistory',
                        contactMethod = '$contactMethod'
                        WHERE patient_ID = '$patient_ID'";

        $updateResult = mysqli_query($dbc, $updateQuery);

        if (mysqli_affected_rows($dbc) == 1) {
            echo "<p>Your profile has been updated successfully.</p>";
        } else {
            echo "<p>An error occurred or no changes were made.</p>";
        }

        echo "<p><a href='patientViewProfile.php'>View Profile</a></p>";
        echo "<p><a href='index.php'>Home</a></p>";
    } else {
        // Display form with pre-filled user data
        echo "<form action='' method='POST'>";
        echo "<p>Name: <input type='text' name='name' value='{$row['name']}'></p>";
        echo "<p>Address: <input type='text' name='address' value='{$row['address']}'></p>";
        echo "<p>Phone Number: <input type='text' name='phoneNumber' value='{$row['phoneNumber']}'></p>";
        echo "<p>Email: <input type='text' name='email' value='{$row['email']}'></p>";
        echo "<p>Password: <input type='password' name='password' value='{$row['password']}'></p>";
        echo "<p>Medical History: <input type='text' name='medHistory' value='{$row['medHistory']}'></p>";
        echo "<p>Preferred Contact Method: <input type='text' name='contactMethod' value='{$row['contactMethod']}'></p>";
        echo "<input type='submit' name='update' value='Update Now'>";
        echo "</form>";
    }
} else {
    echo "<p><b>Error:</b> Invalid user ID.</p>";
}
?>
</body>
</html>
