<?php
require_once('mysqli_connect.php');
session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Bill Payment</title>
</head>
<body>
<?php
if (!isset($_SESSION['login_user'])) {
    echo "<p><b>Error:</b> User not logged in.</p>";
    exit();
}

$patient_ID = $_SESSION['login_user'];

// Handle payment form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['pay'])) {
    $invoiceNumber = uniqid("INV"); // Generate a unique invoice number
    $transactionDate = date('Y-m-d'); // Today's date
    $amount = $_POST['amount'];
    $paymentMethod = $_POST['paymentMethod'];

    $query = "INSERT INTO billPaymentPlaced (invoiceNumber, patient_ID, transactionDate, amount, paymentMethod) 
              VALUES ('$invoiceNumber', '$patient_ID', '$transactionDate', '$amount', '$paymentMethod')";

    $response = mysqli_query($dbc, $query);

    if ($response) {
        echo "<p style='color:green;'>Payment processed successfully. Invoice #: $invoiceNumber</p>";
    } else {
        echo "<p style='color:red;'>Error processing payment: " . mysqli_error($dbc) . "</p>";
    }
}
?>

<h2>Pay Your Bill</h2>
<form method="POST">
    <label for="amount">Amount (USD):</label>
    <input type="number" step="0.01" name="amount" required><br><br>

    <label for="paymentMethod">Payment Method:</label>
    <select name="paymentMethod" required>
        <option value="">Select</option>
        <option value="Credit Card">Credit Card</option>
        <option value="Debit Card">Debit Card</option>
        <option value="PayPal">PayPal</option>
        <option value="Cash">Cash</option>
    </select><br><br>

    <input type="submit" name="pay" value="Pay Now">
</form>

<p><a href="index.php">Back to Home</a></p>
</body>
</html>
