<?php
require_once('mysqli_connect.php');
session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Schedule Appointment</title>
</head>
<body>
<?php
if (!isset($_SESSION['login_user'])) {
    echo "<p><b>Error:</b> User not logged in.</p>";
    exit();
}

$patient_ID = $_SESSION['login_user'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $date = $_POST['date'];
    $time = $_POST['time'];
    $datetime = $date . ' ' . $time . ':00'; // format: YYYY-MM-DD HH:MM:SS

    $appID = uniqid('APP'); // Generates a unique appointment ID

    // Insert new appointment
    $query = "INSERT INTO AppointmentSchedule (appID, patient_ID, date, time)
            VALUES ('$appID', '$patient_ID', '$date', '$datetime')";


    if (mysqli_query($dbc, $query)) {
        // Redirect to view appointments page after successful insertion
        header("Location: patientViewAppointments.php");
        exit; // Ensure no further code is executed after redirect
    } else {
        echo "<p><b>Error:</b> Could not schedule appointment. " . mysqli_error($dbc) . "</p>";
    }
} else {
    // Display form
    ?>
    <h2>Schedule an Appointment</h2>
    <form action="" method="post">
        <p>Date: <input type="date" name="date" required></p>
        <p>Time: <input type="time" name="time" required></p>
        <p><input type="submit" value="Schedule"></p>
    </form>
    <p><a href="index.php">Home</a></p>
    <?php
}
?>
</body>
</html>
