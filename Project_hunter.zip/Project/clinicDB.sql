DROP DATABASE IF EXISTS clinicDB;
CREATE DATABASE clinicDB;
USE clinicDB

SET FOREIGN_KEY_CHECKS=0;
DROP TABLE Results;

CREATE TABLE Patient( 
patient_ID CHAR(9),
ssn CHAR(9),
password VARCHAR(40),
gender CHAR(1),
dateOfBirth DATE,
medHistory VARCHAR(100),
address VARCHAR(100),
phoneNumber CHAR(11),
email VARCHAR(50),
name VARCHAR(50),
contactMethod VARCHAR(20),
PRIMARY KEY (patient_ID),
UNIQUE(ssn)
);

select * from patient

CREATE TABLE AppointmentSchedule( 
appID CHAR(9),
patient_ID CHAR(9),
date DATE,
time TIMESTAMP,
PRIMARY KEY(appID),
FOREIGN KEY(patient_ID) REFERENCES Patient(patient_ID)
);


CREATE TABLE DoctorWork( 
docID CHAR(9),
name VARCHAR(50),
email VARCHAR(50),
password VARCHAR(40),
appID CHAR(9),
PRIMARY KEY(docID),
FOREIGN KEY(appID) REFERENCES AppointmentSchedule(appID)
);


CREATE TABLE Results(
testResults VARCHAR(100),
date DATE,
notes VARCHAR(300),
prescription VARCHAR(100),
docID CHAR(9),
diagnosis VARCHAR(50),
patient_ID CHAR(9),
exam_ID CHAR(9),
PRIMARY KEY(exam_ID),
FOREIGN KEY(patient_ID) REFERENCES Patient(patient_ID),
FOREIGN KEY(docID) REFERENCES DoctorWork(docID)
);

CREATE TABLE Exam(
patient_ID CHAR(9),
exam_ID CHAR(9),
docID CHAR(9),
PRIMARY KEY(patient_ID, exam_ID, docID),
FOREIGN KEY(patient_ID) REFERENCES Patient(patient_ID),
FOREIGN KEY(exam_ID) REFERENCES Results(exam_ID),
FOREIGN KEY(docID) REFERENCES DoctorWork(docID)
);

CREATE TABLE Prescription(
    prescription_ID CHAR(9),
    prescriptionDetails VARCHAR(100),
    expirationDate DATE,
    dateIssued DATE,
    exam_ID CHAR(9),
    patient_ID CHAR(9),
    PRIMARY KEY(prescription_ID),
    FOREIGN KEY(exam_ID) REFERENCES Results(exam_ID),
    FOREIGN KEY(patient_ID) REFERENCES Patient(patient_ID)
);

CREATE TABLE Issues(
    exam_ID CHAR(9),
    prescription_ID CHAR(9),
    PRIMARY KEY(exam_ID, prescription_ID),
    FOREIGN KEY(exam_ID) REFERENCES Results(exam_ID),
    FOREIGN KEY(prescription_ID) REFERENCES Prescription(prescription_ID)
);

CREATE TABLE Orders(
patient_ID CHAR(9),
totalAmount INT,
orderDate DATE,
order_ID CHAR(9),
PRIMARY KEY(order_ID),
FOREIGN KEY(patient_ID) REFERENCES Patient(patient_ID)
);

CREATE TABLE Items(
    productType VARCHAR(50),
    qtyInStock INT,
    itemName VARCHAR(50),
    item_ID CHAR(9),
    salePrice DECIMAL(6,2),
    order_ID CHAR(9),
    PRIMARY KEY(item_ID),
    FOREIGN KEY(order_ID) REFERENCES Orders(order_ID)
);

CREATE TABLE Includes(
    quantity INT,
    order_ID CHAR(9),
    item_ID CHAR(9),
    PRIMARY KEY(order_ID, item_ID),
    FOREIGN KEY(order_ID) REFERENCES Orders(order_ID),
    FOREIGN KEY(item_ID) REFERENCES Items(item_ID)
);

CREATE TABLE billPaymentPlaced(
invoiceNumber VARCHAR(10),
patient_ID CHAR(9),
transactionDate DATE,
amount DECIMAL(6,2),
paymentMethod VARCHAR(30),
PRIMARY Key(invoiceNumber),
FOREIGN KEY(patient_ID) REFERENCES Patient(patient_ID)
);

SELECT * From exam

--Records for Patient table
INSERT INTO Patient (patient_ID, ssn, password, gender, dateOfBirth, medHistory, address, phoneNumber, email, name, contactMethod) 
VALUES  ('P12345678', '123456789', 'SecurePass123!', 'M', '1990-05-15', 'No known allergies', '123 Main St, City, State', '12345678901', 'john.doe@email.com', 'John Doe', 'Email');
INSERT INTO Patient (patient_ID, ssn, password, gender, dateOfBirth, medHistory, address, phoneNumber, email, name, contactMethod) 
VALUES  
('P12345679', '987654321', 'StrongPass456!', 'F', '1985-08-25', 'Asthma', '456 Elm St, City, State', '98765432101', 'jane.doe@email.com', 'Jane Doe', 'Email'),
('P12345680', '456123789', 'PassWord@789', 'M', '1992-11-13', 'Peanut allergy', '789 Oak St, City, State', '45612378902', 'michael.smith@email.com', 'Michael Smith', 'SMS'),
('P12345681', '159357456', 'SafePass!123', 'F', '1995-07-30', 'None', '101 Pine St, City, State', '15935745603', 'emily.jones@email.com', 'Emily Jones', 'Phone'),
('P12345682', '753951852', 'HealthPass456', 'M', '1988-04-18', 'Diabetes Type 1', '102 Cedar St, City, State', '75395185204', 'robert.brown@email.com', 'Robert Brown', 'Email'),
('P12345683', '852369741', 'UniquePass987!', 'F', '1999-06-22', 'Lactose intolerance', '103 Birch St, City, State', '85236974105', 'sarah.davis@email.com', 'Sarah Davis', 'SMS'),
('P12345684', '741852963', 'Secure456Pass', 'M', '1993-12-10', 'Gluten allergy', '104 Maple St, City, State', '74185296306', 'david.miller@email.com', 'David Miller', 'Phone'),
('P12345685', '369258147', 'ExtraSafePass!', 'F', '2000-09-05', 'Mild seasonal allergies', '105 Walnut St, City, State', '36925814707', 'jessica.wilson@email.com', 'Jessica Wilson', 'Email'),
('P12345686', '963852741', 'HardPass321!', 'M', '1982-03-27', 'Hypertension', '106 Aspen St, City, State', '96385274108', 'chris.moore@email.com', 'Chris Moore', 'SMS'),
('P12345687', '258741369', 'CoolPass222', 'F', '1994-01-14', 'Anemia', '107 Cherry St, City, State', '25874136909', 'laura.taylor@email.com', 'Laura Taylor', 'Phone'),
('P12345688', '159753486', 'TopSecret555!', 'M', '1980-10-19', 'Heart disease', '108 Peach St, City, State', '15975348610', 'brian.anderson@email.com', 'Brian Anderson', 'Email'),
('P12345689', '456789123', 'MyPassword321!', 'F', '1996-02-17', 'None', '109 Plum St, City, State', '45678912311', 'ashley.thomas@email.com', 'Ashley Thomas', 'SMS'),
('P12345690', '789456123', 'Pass@123Pass', 'M', '1991-07-06', 'No known allergies', '110 Pineapple St, City, State', '78945612312', 'matthew.jackson@email.com', 'Matthew Jackson', 'Email'),
('P12345691', '357951486', 'MyHealth2024!', 'F', '1987-05-09', 'None', '111 Coconut St, City, State', '35795148613', 'elizabeth.white@email.com', 'Elizabeth White', 'Phone'),
('P12345692', '654987321', 'Secured456Pass', 'M', '1998-12-23', 'None', '112 Lemon St, City, State', '65498732114', 'joshua.harris@email.com', 'Joshua Harris', 'Email'),
('P12345693', '852147369', 'UltraSafePass1!', 'F', '1986-04-04', 'Mild asthma', '113 Orange St, City, State', '85214736915', 'melissa.clark@email.com', 'Melissa Clark', 'SMS'),
('P12345694', '321654987', 'UniquePass000!', 'M', '2001-11-29', 'Hay fever', '114 Apple St, City, State', '32165498716', 'kevin.rodriguez@email.com', 'Kevin Rodriguez', 'Phone'),
('P12345695', '741963258', 'SuperHealthPass!', 'F', '1984-09-08', 'Mild anemia', '115 Pear St, City, State', '74196325817', 'samantha.lewis@email.com', 'Samantha Lewis', 'Email'),
('P12345696', '852369147', 'ComplexPass777!', 'M', '1997-03-15', 'None', '116 Grape St, City, State', '85236914718', 'ryan.walker@email.com', 'Ryan Walker', 'SMS'),
('P12345697', '987321654', 'SecretHealth2025!', 'F', '1990-08-12', 'Lactose intolerance', '117 Strawberry St, City, State', '98732165419', 'olivia.hall@email.com', 'Olivia Hall', 'Email'),
('P12345698', '654321987', 'MySuperPass123!', 'M', '1983-06-11', 'Hypertension', '118 Raspberry St, City, State', '65432198720', 'tyler.allen@email.com', 'Tyler Allen', 'Phone'),
('P12345699', '753159468', 'VerySafePass666!', 'F', '1995-10-26', 'None', '119 Blueberry St, City, State', '75315946821', 'natalie.young@email.com', 'Natalie Young', 'SMS'),
('P12345700', '951753852', 'Password444!', 'M', '1981-01-30', 'Heart disease', '120 Blackberry St, City, State', '95175385222', 'zachary.hernandez@email.com', 'Zachary Hernandez', 'Email'),
('P12345701', '369852147', 'BestHealthPass!', 'F', '2002-07-14', 'No known allergies', '121 Cranberry St, City, State', '36985214723', 'amanda.king@email.com', 'Amanda King', 'SMS'),
('P12345702', '852741369', 'OneSafePass!', 'M', '1993-04-25', 'Peanut allergy', '122 Watermelon St, City, State', '85274136924', 'justin.wright@email.com', 'Justin Wright', 'Email'),
('P12345703', '159486753', 'AnotherPass321!', 'F', '1992-12-07', 'None', '123 Banana St, City, State', '15948675325', 'stephanie.lopez@email.com', 'Stephanie Lopez', 'Phone'),
('P12345704', '258963147', 'PassItSecure!', 'M', '1989-11-16', 'None', '124 Kiwi St, City, State', '25896314726', 'brandon.scott@email.com', 'Brandon Scott', 'SMS'),
('P12345705', '654789321', 'SecretKeeper555!', 'F', '1996-05-02', 'None', '125 Mango St, City, State', '65478932127', 'rachel.green@email.com', 'Rachel Green', 'Email'),
('P12345706', '112233445', 'PassGreen123!', 'M', '1980-02-29', 'Chronic migraines', '301 Ocean Dr, Miami, FL', '3055556789', 'leo.waters@email.com', 'Leo Waters', 'Email'),
('P12345707', '223344556', 'SkyBluePass789!', 'F', '1975-06-17', 'High cholesterol', '402 Sunset Blvd, Los Angeles, CA', '3109876543', 'marissa.sage@email.com', 'Marissa Sage', 'SMS'),
('P12345708', '334455667', 'CactusSecure456!', 'M', '1988-12-05', 'Broken left wrist (2015)', '505 Desert Rd, Phoenix, AZ', '6023457890', 'owen.martinez@email.com', 'Owen Martinez', 'Phone'),
('P12345709', '445566778', 'NightOwlPass555!', 'F', '1997-03-08', 'Frequent nosebleeds', '607 Forest Ln, Portland, OR', '5031234567', 'fiona.rivers@email.com', 'Fiona Rivers', 'Email'),
('P12345710', '556677889', 'RocketMan123!', 'M', '2000-10-21', 'No known conditions', '708 Lunar St, Houston, TX', '7135678901', 'elijah.stone@email.com', 'Elijah Stone', 'SMS'),
('P12345711', '667788990', 'PassStorm2024!', 'F', '1983-05-14', 'Severe nut allergy', '809 Thunder Ave, Denver, CO', '7209871234', 'lydia.hawthorne@email.com', 'Lydia Hawthorne', 'Phone'),
('P12345712', '778899001', 'WinterSafe999!', 'M', '1991-11-30', 'History of concussions', '910 Snowfall Dr, Anchorage, AK', '9076543210', 'jack.frost@email.com', 'Jack Frost', 'Email'),
('P12345713', '889900112', 'GoldenGate456!', 'F', '1978-08-11', 'Past heart surgery (2010)', '1001 Bridge St, San Francisco, CA', '4152223344', 'sophia.bridge@email.com', 'Sophia Bridge', 'Phone'),
('P12345714', '990011223', 'JazzClub888!', 'M', '1969-09-23', 'Arthritis', '202 Blues Rd, New Orleans, LA', '5048765432', 'marvin.soul@email.com', 'Marvin Soul', 'SMS'),
('P12345715', '101122334', 'SunsetView321!', 'F', '2004-07-04', 'None', '303 Beachside Ave, San Diego, CA', '6193456789', 'lily.sands@email.com', 'Lily Sands', 'Email'),
('P12345716', '112233446', 'AuroraSky777!', 'M', '1995-12-15', 'Asthma', '404 Northern Lights St, Fairbanks, AK', '9071112233', 'ethan.north@email.com', 'Ethan North', 'SMS');
INSERT INTO Patient (patient_ID, ssn, password, gender, dateOfBirth, medHistory, address, phoneNumber, email, name, contactMethod) 
VALUES  
('P12345717', '123321123', 'BrightFuture2025!', 'F', '1999-01-11', 'Migraines', '126 Nectarine St, City, State', '12332112328', 'megan.sun@email.com', 'Megan Sun', 'Email');

SELECT COUNT(*)
FROM Patient;

--Records for DoctorWork table
INSERT INTO DoctorWork (docID, name, email, password, appID) VALUES
('DOC000001', 'Dr. Alice Smith', 'asmith1@example.com', 'pass1234', 'A10000001'),
('DOC000002', 'Dr. Bob Jones', 'bjones2@example.com', 'qwerty99', 'A10000002'),
('DOC000003', 'Dr. Carla Davis', 'cdavis3@example.com', 'letmein88', 'A10000003'),
('DOC000004', 'Dr. Daniel Lee', 'dlee4@example.com', 'abc12345', 'A10000004'),
('DOC000005', 'Dr. Ella Kim', 'ekim5@example.com', 'pass4567', 'A10000005'),
('DOC000006', 'Dr. Frank Moore', 'fmoore6@example.com', 'mypwd321', 'A10000006'),
('DOC000007', 'Dr. Grace Liu', 'gliu7@example.com', 'sunshine7', 'A10000007'),
('DOC000008', 'Dr. Henry Patel', 'hpatel8@example.com', 'hunter22', 'A10000008'),
('DOC000009', 'Dr. Irene Garcia', 'igarcia9@example.com', 'zebra789', 'A10000009'),
('DOC000010', 'Dr. Jack Wang', 'jwang10@example.com', 'login432', 'A10000010'),
('DOC000011', 'Dr. Kate Brown', 'kbrown11@example.com', 'password1', 'A10000011'),
('DOC000012', 'Dr. Leo Green', 'lgreen12@example.com', 'alpha456', 'A10000012'),
('DOC000013', 'Dr. Mia White', 'mwhite13@example.com', 'safecode9', 'A10000013'),
('DOC000014', 'Dr. Nick Hall', 'nhall14@example.com', 'letmein77', 'A10000014'),
('DOC000015', 'Dr. Olivia Young', 'oyoung15@example.com', 'secret123', 'A10000015'),
('DOC000016', 'Dr. Paul King', 'pking16@example.com', 'pw123456', 'A10000016'),
('DOC000017', 'Dr. Quinn Scott', 'qscott17@example.com', 'hunter33', 'A10000017'),
('DOC000018', 'Dr. Rachel Adams', 'radams18@example.com', 'hello321', 'A10000018'),
('DOC000019', 'Dr. Steve Clark', 'sclark19@example.com', 'bluebird1', 'A10000019'),
('DOC000020', 'Dr. Tina Lopez', 'tlopez20@example.com', 'strongpwd', 'A10000020'),
('DOC000021', 'Dr. Umar Khan', 'ukhan21@example.com', 'ocean777', 'A10000021'),
('DOC000022', 'Dr. Vera Shah', 'vshah22@example.com', 'redapple3', 'A10000022'),
('DOC000023', 'Dr. Will Reed', 'wreed23@example.com', 'niceone11', 'A10000023'),
('DOC000024', 'Dr. Xena Tran', 'xtran24@example.com', 'g00dpass', 'A10000024'),
('DOC000025', 'Dr. Yara Lin', 'ylin25@example.com', 'tryme123', 'A10000025'),
('DOC000026', 'Dr. Zack Fox', 'zfox26@example.com', 'ilove789', 'A10000026'),
('DOC000027', 'Dr. Amber Knight', 'aknight27@example.com', 'cloud999', 'A10000027'),
('DOC000028', 'Dr. Ben Hunter', 'bhunter28@example.com', 'drive777', 'A10000028'),
('DOC000029', 'Dr. Cindy Neal', 'cneal29@example.com', 'lookhere1', 'A10000029'),
('DOC000030', 'Dr. Dave Owens', 'dowens30@example.com', 'password2', 'A10000030'),
('DOC000031', 'Dr. Erin West', 'ewest31@example.com', 'open7890', 'A10000031'),
('DOC000032', 'Dr. Felix Ray', 'fray32@example.com', 'alaska55', 'A10000032'),
('DOC000033', 'Dr. Gina Bell', 'gbell33@example.com', 'forest22', 'A10000033'),
('DOC000034', 'Dr. Hugh Nash', 'hnash34@example.com', 'quiet123', 'A10000034'),
('DOC000035', 'Dr. Isla Perry', 'iperry35@example.com', 'storm888', 'A10000035'),
('DOC000036', 'Dr. Jake Miles', 'jmiles36@example.com', 'bright99', 'A10000036'),
('DOC000037', 'Dr. Kara Shaw', 'kshaw37@example.com', 'night456', 'A10000037'),
('DOC000038', 'Dr. Liam Ross', 'lross38@example.com', 'lamp1234', 'A10000038'),
('DOC000039', 'Dr. Maya Stone', 'mstone39@example.com', 'echo0001', 'A10000039'),
('DOC000040', 'Dr. Noah Fry', 'nfry40@example.com', 'pw09876', 'A10000040');



SELECT count(*) FROM Doctor

--Records for AppointmentSchedule table
INSERT INTO AppointmentSchedule (appID, patient_ID, date, time) VALUES  ('A10000001', 'P12345678', '2025-03-20', '2025-03-20 10:30:00');
INSERT INTO AppointmentSchedule (appID, patient_ID, date, time) VALUES  
('A10000002', 'P12345678', '2025-04-01', '2025-04-01 09:00:00'),
('A10000003', 'P12345679', '2025-04-02', '2025-04-02 10:00:00'),
('A10000004', 'P12345680', '2025-04-03', '2025-04-03 11:00:00'),
('A10000005', 'P12345681', '2025-04-04', '2025-04-04 13:30:00'),
('A10000006', 'P12345682', '2025-04-05', '2025-04-05 14:00:00'),
('A10000007', 'P12345683', '2025-04-06', '2025-04-06 15:30:00'),
('A10000008', 'P12345684', '2025-04-07', '2025-04-07 08:45:00'),
('A10000009', 'P12345685', '2025-04-08', '2025-04-08 09:15:00'),
('A10000010', 'P12345686', '2025-04-09', '2025-04-09 10:45:00'),
('A10000011', 'P12345687', '2025-04-10', '2025-04-10 11:30:00'),
('A10000012', 'P12345688', '2025-04-11', '2025-04-11 13:00:00'),
('A10000013', 'P12345689', '2025-04-12', '2025-04-12 14:30:00'),
('A10000014', 'P12345690', '2025-04-13', '2025-04-13 15:00:00'),
('A10000015', 'P12345691', '2025-04-14', '2025-04-14 16:00:00'),
('A10000016', 'P12345692', '2025-04-15', '2025-04-15 09:30:00'),
('A10000017', 'P12345693', '2025-04-16', '2025-04-16 10:00:00'),
('A10000018', 'P12345694', '2025-04-17', '2025-04-17 11:30:00'),
('A10000019', 'P12345695', '2025-04-18', '2025-04-18 13:00:00'),
('A10000020', 'P12345696', '2025-04-19', '2025-04-19 14:45:00'),
('A10000021', 'P12345697', '2025-04-20', '2025-04-20 08:30:00'),
('A10000022', 'P12345698', '2025-04-21', '2025-04-21 09:45:00'),
('A10000023', 'P12345699', '2025-04-22', '2025-04-22 10:15:00'),
('A10000024', 'P12345700', '2025-04-23', '2025-04-23 11:45:00'),
('A10000025', 'P12345701', '2025-04-24', '2025-04-24 12:30:00'),
('A10000026', 'P12345702', '2025-04-25', '2025-04-25 14:00:00'),
('A10000027', 'P12345703', '2025-04-26', '2025-04-26 15:15:00'),
('A10000028', 'P12345704', '2025-04-27', '2025-04-27 16:30:00'),
('A10000029', 'P12345705', '2025-04-28', '2025-04-28 09:00:00'),
('A10000030', 'P12345706', '2025-04-29', '2025-04-29 10:30:00'),
('A10000031', 'P12345707', '2025-04-30', '2025-04-30 12:00:00'),
('A10000032', 'P12345708', '2025-05-01', '2025-05-01 13:45:00'),
('A10000033', 'P12345709', '2025-05-02', '2025-05-02 14:15:00'),
('A10000034', 'P12345710', '2025-05-03', '2025-05-03 15:30:00'),
('A10000035', 'P12345711', '2025-05-04', '2025-05-04 08:00:00'),
('A10000036', 'P12345712', '2025-05-05', '2025-05-05 09:30:00'),
('A10000037', 'P12345713', '2025-05-06', '2025-05-06 10:45:00'),
('A10000038', 'P12345714', '2025-05-07', '2025-05-07 11:15:00'),
('A10000039', 'P12345715', '2025-05-08', '2025-05-08 12:45:00'),
('A10000040', 'P12345716', '2025-05-09', '2025-05-09 14:00:00');

SELECT COUNT(*) FROM AppointmentSchedule;

--Records for Results table
INSERT INTO Results (testResults, date, notes, prescription, docID, diagnosis, patient_ID, exam_ID) VALUES
('20/20 vision confirmed', '2025-03-20', 'No corrective lenses needed.', 'None', 'DOC000001', 'Normal Vision', 'P12345678', 'EX000001'),
('Slight nearsightedness detected', '2025-04-01', 'Patient reports blurry distance vision.', 'Prescription glasses', 'DOC000002', 'Myopia', 'P12345678', 'EX000002'),
('Moderate farsightedness found', '2025-04-02', 'Difficulty with close-up tasks.', 'Reading glasses', 'DOC000003', 'Hyperopia', 'P12345679', 'EX000003'),
('Signs of astigmatism', '2025-04-03', 'Distorted vision reported.', 'Toric lenses', 'DOC000004', 'Astigmatism', 'P12345680', 'EX000004'),
('Elevated intraocular pressure', '2025-04-04', 'Risk of glaucoma.', 'Latanoprost drops', 'DOC000005', 'Glaucoma Suspect', 'P12345681', 'EX000005'),
('Early stage cataracts', '2025-04-05', 'Mild lens clouding noted.', 'Monitor yearly', 'DOC000006', 'Cataracts', 'P12345682', 'EX000006'),
('Dry eyes diagnosed', '2025-04-06', 'Burning, gritty sensation.', 'Artificial tears', 'DOC000007', 'Dry Eye Syndrome', 'P12345683', 'EX000007'),
('Retinal exam normal', '2025-04-07', 'No signs of degeneration.', 'None', 'DOC000008', 'Normal Retina', 'P12345684', 'EX000008'),
('Conjunctivitis (pink eye)', '2025-04-08', 'Redness, irritation and discharge.', 'Antibiotic drops', 'DOC000009', 'Conjunctivitis', 'P12345685', 'EX000009'),
('Floaters observed', '2025-04-09', 'Benign vitreous changes.', 'None', 'DOC000010', 'Vitreous Floaters', 'P12345686', 'EX000010'),
('Macula appears healthy', '2025-04-10', 'No signs of degeneration.', 'None', 'DOC000011', 'Normal Macula', 'P12345687', 'EX000011'),
('Color blindness test failed (red-green)', '2025-04-11', 'Ishihara test inconclusive.', 'N/A', 'DOC000012', 'Color Deficiency', 'P12345688', 'EX000012'),
('Eye alignment normal', '2025-04-12', 'No strabismus detected.', 'None', 'DOC000013', 'Normal Alignment', 'P12345689', 'EX000013'),
('Corneal abrasion healing', '2025-04-13', 'Follow-up from eye injury.', 'Antibiotic ointment', 'DOC000014', 'Corneal Abrasion', 'P12345690', 'EX000014'),
('Infection in eyelid', '2025-04-14', 'Swelling and tenderness present.', 'Warm compress, antibiotics', 'DOC000015', 'Stye', 'P12345691', 'EX000015'),
('Eye strain from screen use', '2025-04-15', 'Patient uses computer 10+ hrs/day.', 'Blue light filter glasses', 'DOC000016', 'Digital Eye Strain', 'P12345692', 'EX000016'),
('Mild ptosis of eyelid', '2025-04-16', 'Drooping observed.', 'Monitor condition', 'DOC000017', 'Ptosis', 'P12345693', 'EX000017'),
('Glasses prescription updated', '2025-04-17', 'Slight myopic progression.', 'New lenses', 'DOC000018', 'Myopia', 'P12345694', 'EX000018'),
('Ocular migraine signs', '2025-04-18', 'Visual aura reported.', 'Monitor symptoms', 'DOC000019', 'Ocular Migraine', 'P12345695', 'EX000019'),
('Allergic conjunctivitis', '2025-04-19', 'Seasonal allergy symptoms.', 'Antihistamine drops', 'DOC000020', 'Allergic Conjunctivitis', 'P12345696', 'EX000020'),
('Blepharitis symptoms', '2025-04-20', 'Eyelid inflammation and flaking.', 'Lid hygiene routine', 'DOC000021', 'Blepharitis', 'P12345697', 'EX000021'),
('Pupil response normal', '2025-04-21', 'Reactive to light bilaterally.', 'None', 'DOC000022', 'Normal Pupil Function', 'P12345698', 'EX000022'),
('Diabetic retinopathy (mild)', '2025-04-22', 'Patient has 5-year diabetes history.', 'Tight glucose control', 'DOC000023', 'Diabetic Retinopathy', 'P12345699', 'EX000023'),
('Corneal clarity intact', '2025-04-23', 'Transparent and unscarred.', 'None', 'DOC000024', 'Normal Cornea', 'P12345700', 'EX000024'),
('Presbyopia confirmed', '2025-04-24', 'Difficulty reading fine print.', 'Reading glasses', 'DOC000025', 'Presbyopia', 'P12345701', 'EX000025'),
('No signs of uveitis', '2025-04-25', 'Anterior chamber clear.', 'None', 'DOC000026', 'Normal Exam', 'P12345702', 'EX000026'),
('Optic nerve appears healthy', '2025-04-26', 'Cup-to-disc ratio within normal.', 'None', 'DOC000027', 'Normal Optic Nerve', 'P12345703', 'EX000027'),
('Pinguecula observed', '2025-04-27', 'Non-cancerous yellow growth.', 'Lubricating drops', 'DOC000028', 'Pinguecula', 'P12345704', 'EX000028'),
('Keratoconus early signs', '2025-04-28', 'Cone-shaped cornea detected.', 'Specialty lenses', 'DOC000029', 'Keratoconus', 'P12345705', 'EX000029'),
('Eye pressure borderline', '2025-04-29', 'Recommended follow-up.', 'Timolol drops', 'DOC000030', 'Ocular Hypertension', 'P12345706', 'EX000030'),
('Foreign body removed', '2025-04-30', 'Debris in lower lid.', 'Antibiotic ointment', 'DOC000031', 'Foreign Body', 'P12345707', 'EX000031'),
('LASIK evaluation', '2025-05-01', 'Patient interested in surgery.', 'Referral to specialist', 'DOC000032', 'Refractive Error', 'P12345708', 'EX000032'),
('Amblyopia detected', '2025-05-02', 'Left eye underdeveloped vision.', 'Eye patching therapy', 'DOC000033', 'Amblyopia', 'P12345709', 'EX000033'),
('Optic disc swelling', '2025-05-03', 'Possible increased intracranial pressure.', 'MRI referral', 'DOC000034', 'Papilledema', 'P12345710', 'EX000034'),
('Pupil dilation completed', '2025-05-04', 'Fundus exam done successfully.', 'None', 'DOC000035', 'Routine Exam', 'P12345711', 'EX000035'),
('Contact lens intolerance', '2025-05-05', 'Dryness and redness noted.', 'Switch to glasses', 'DOC000036', 'Lens Discomfort', 'P12345712', 'EX000036'),
('Peripheral vision normal', '2025-05-06', 'Full field of vision.', 'None', 'DOC000037', 'Normal Vision Field', 'P12345713', 'EX000037'),
('Eye trauma healing well', '2025-05-07', 'Follow-up after blunt injury.', 'Protective shield', 'DOC000038', 'Eye Trauma', 'P12345714', 'EX000038'),
('No signs of AMD', '2025-05-08', 'Macula intact, no drusen.', 'None', 'DOC000039', 'Age-Related Macular Degeneration (ruled out)', 'P12345715', 'EX000039'),
('Normal slit lamp exam', '2025-05-09', 'Anterior segment clear.', 'None', 'DOC000040', 'Normal Exam', 'P12345716', 'EX000040');


SELECT * FROM Results

--Records from Exam Table
INSERT INTO Exam (patient_ID, exam_ID, docID) VALUES
('P12345678', 'EX000001', 'DOC000001'),
('P12345678', 'EX000002', 'DOC000002'),
('P12345679', 'EX000003', 'DOC000003'),
('P12345680', 'EX000004', 'DOC000004'),
('P12345681', 'EX000005', 'DOC000005'),
('P12345682', 'EX000006', 'DOC000006'),
('P12345683', 'EX000007', 'DOC000007'),
('P12345684', 'EX000008', 'DOC000008'),
('P12345685', 'EX000009', 'DOC000009'),
('P12345686', 'EX000010', 'DOC000010'),
('P12345687', 'EX000011', 'DOC000011'),
('P12345688', 'EX000012', 'DOC000012'),
('P12345689', 'EX000013', 'DOC000013'),
('P12345690', 'EX000014', 'DOC000014'),
('P12345691', 'EX000015', 'DOC000015'),
('P12345692', 'EX000016', 'DOC000016'),
('P12345693', 'EX000017', 'DOC000017'),
('P12345694', 'EX000018', 'DOC000018'),
('P12345695', 'EX000019', 'DOC000019'),
('P12345696', 'EX000020', 'DOC000020'),
('P12345697', 'EX000021', 'DOC000021'),
('P12345698', 'EX000022', 'DOC000022'),
('P12345699', 'EX000023', 'DOC000023'),
('P12345700', 'EX000024', 'DOC000024'),
('P12345701', 'EX000025', 'DOC000025'),
('P12345702', 'EX000026', 'DOC000026'),
('P12345703', 'EX000027', 'DOC000027'),
('P12345704', 'EX000028', 'DOC000028'),
('P12345705', 'EX000029', 'DOC000029'),
('P12345706', 'EX000030', 'DOC000030'),
('P12345707', 'EX000031', 'DOC000031'),
('P12345708', 'EX000032', 'DOC000032'),
('P12345709', 'EX000033', 'DOC000033'),
('P12345710', 'EX000034', 'DOC000034'),
('P12345711', 'EX000035', 'DOC000035'),
('P12345712', 'EX000036', 'DOC000036'),
('P12345713', 'EX000037', 'DOC000037'),
('P12345714', 'EX000038', 'DOC000038'),
('P12345715', 'EX000039', 'DOC000039'),
('P12345716', 'EX000040', 'DOC000040');

SELECT COUNT(*) FROM Exam

--Records for Prescription Table
INSERT INTO Prescription (prescription_ID, prescriptionDetails, expirationDate, dateIssued, exam_ID, patient_ID) VALUES
('RX000001', 'Eyeglasses - Single vision lenses', '2025-06-20', '2025-03-20', 'EX000001', 'P12345678'),
('RX000002', 'Contact lenses - monthly disposable', '2025-06-21', '2025-03-21', 'EX000002', 'P12345678'),
('RX000003', 'Artificial tears - lubricating drops', '2025-06-22', '2025-03-22', 'EX000003', 'P12345679'),
('RX000004', 'Prescription sunglasses', '2025-06-23', '2025-03-23', 'EX000004', 'P12345680'),
('RX000005', 'Anti-allergy eye drops', '2025-06-24', '2025-03-24', 'EX000005', 'P12345681'),
('RX000006', 'Bifocal lenses', '2025-06-25', '2025-03-25', 'EX000006', 'P12345682'),
('RX000007', 'Antibiotic eye drops - conjunctivitis', '2025-06-26', '2025-03-26', 'EX000007', 'P12345683'),
('RX000008', 'Eyeglasses - Blue light filtering', '2025-06-27', '2025-03-27', 'EX000008', 'P12345684'),
('RX000009', 'Prescription for astigmatism correction', '2025-06-28', '2025-03-28', 'EX000009', 'P12345685'),
('RX000010', 'High-index lenses prescription', '2025-06-29', '2025-03-29', 'EX000010', 'P12345686'),
('RX000011', 'Progressive lenses', '2025-06-30', '2025-03-30', 'EX000011', 'P12345687'),
('RX000012', 'Corticosteroid eye drops', '2025-07-01', '2025-03-31', 'EX000012', 'P12345688'),
('RX000013', 'Reading glasses - +1.75', '2025-07-02', '2025-04-01', 'EX000013', 'P12345689'),
('RX000014', 'Multifocal contact lenses', '2025-07-03', '2025-04-02', 'EX000014', 'P12345690'),
('RX000015', 'Night vision enhancement lenses', '2025-07-04', '2025-04-03', 'EX000015', 'P12345691'),
('RX000016', 'Preservative-free eye drops', '2025-07-05', '2025-04-04', 'EX000016', 'P12345692'),
('RX000017', 'Glaucoma medication', '2025-07-06', '2025-04-05', 'EX000017', 'P12345693'),
('RX000018', 'Allergy eye drops (olopatadine)', '2025-07-07', '2025-04-06', 'EX000018', 'P12345694'),
('RX000019', 'Eyeglasses - Distance vision only', '2025-07-08', '2025-04-07', 'EX000019', 'P12345695'),
('RX000020', 'Eye ointment for dry eyes', '2025-07-09', '2025-04-08', 'EX000020', 'P12345696'),
('RX000021', 'Vitamin A supplements for eye health', '2025-07-10', '2025-04-09', 'EX000021', 'P12345697'),
('RX000022', 'Polarized lenses for sun protection', '2025-07-11', '2025-04-10', 'EX000022', 'P12345698'),
('RX000023', 'Anti-reflective coating lenses', '2025-07-12', '2025-04-11', 'EX000023', 'P12345699'),
('RX000024', 'Corrective lenses for myopia', '2025-07-13', '2025-04-12', 'EX000024', 'P12345700'),
('RX000025', 'Eye drops for redness relief', '2025-07-14', '2025-04-13', 'EX000025', 'P12345701'),
('RX000026', 'Prescription for hyperopia correction', '2025-07-15', '2025-04-14', 'EX000026', 'P12345702'),
('RX000027', 'Prescription contact lenses for astigmatism', '2025-07-16', '2025-04-15', 'EX000027', 'P12345703'),
('RX000028', 'Eye gel for nighttime dryness', '2025-07-17', '2025-04-16', 'EX000028', 'P12345704'),
('RX000029', 'Nutritional supplements for AMD', '2025-07-18', '2025-04-17', 'EX000029', 'P12345705'),
('RX000030', 'Pupil-dilating eye drops', '2025-07-19', '2025-04-18', 'EX000030', 'P12345706'),
('RX000031', 'Contact lenses - daily disposable', '2025-07-20', '2025-04-19', 'EX000031', 'P12345707'),
('RX000032', 'Eyeglasses - prism correction', '2025-07-21', '2025-04-20', 'EX000032', 'P12345708'),
('RX000033', 'Blue light protection lenses', '2025-07-22', '2025-04-21', 'EX000033', 'P12345709'),
('RX000034', 'Computer glasses', '2025-07-23', '2025-04-22', 'EX000034', 'P12345710'),
('RX000035', 'Prescription lenses with UV protection', '2025-07-24', '2025-04-23', 'EX000035', 'P12345711'),
('RX000036', 'Anti-fog prescription glasses', '2025-07-25', '2025-04-24', 'EX000036', 'P12345712'),
('RX000037', 'Prescription for amblyopia therapy', '2025-07-26', '2025-04-25', 'EX000037', 'P12345713'),
('RX000038', 'Latanoprost eye drops for IOP', '2025-07-27', '2025-04-26', 'EX000038', 'P12345714'),
('RX000039', 'Low vision aids', '2025-07-28', '2025-04-27', 'EX000039', 'P12345715'),
('RX000040', 'Anti-bacterial eye drops', '2025-07-29', '2025-04-28', 'EX000040', 'P12345716');

SELECT COUNT(*) FROM Prescription

--Records for Issues table
INSERT INTO Issues (exam_ID, prescription_ID) VALUES
('EX000001', 'RX000001'),
('EX000002', 'RX000002'),
('EX000003', 'RX000003'),
('EX000004', 'RX000004'),
('EX000005', 'RX000005'),
('EX000006', 'RX000006'),
('EX000007', 'RX000007'),
('EX000008', 'RX000008'),
('EX000009', 'RX000009'),
('EX000010', 'RX000010'),
('EX000011', 'RX000011'),
('EX000012', 'RX000012'),
('EX000013', 'RX000013'),
('EX000014', 'RX000014'),
('EX000015', 'RX000015'),
('EX000016', 'RX000016'),
('EX000017', 'RX000017'),
('EX000018', 'RX000018'),
('EX000019', 'RX000019'),
('EX000020', 'RX000020'),
('EX000021', 'RX000021'),
('EX000022', 'RX000022'),
('EX000023', 'RX000023'),
('EX000024', 'RX000024'),
('EX000025', 'RX000025'),
('EX000026', 'RX000026'),
('EX000027', 'RX000027'),
('EX000028', 'RX000028'),
('EX000029', 'RX000029'),
('EX000030', 'RX000030'),
('EX000031', 'RX000031'),
('EX000032', 'RX000032'),
('EX000033', 'RX000033'),
('EX000034', 'RX000034'),
('EX000035', 'RX000035'),
('EX000036', 'RX000036'),
('EX000037', 'RX000037'),
('EX000038', 'RX000038'),
('EX000039', 'RX000039'),
('EX000040', 'RX000040');


--Records for Orders table
INSERT INTO Orders (patient_ID, totalAmount, orderDate, order_ID) VALUES
('P12345678', 120, '2025-03-21', 'ORD000001'),
('P12345678', 75, '2025-03-22', 'ORD000002'),
('P12345679', 150, '2025-03-23', 'ORD000003'),
('P12345680', 210, '2025-03-24', 'ORD000004'),
('P12345681', 95, '2025-03-25', 'ORD000005'),
('P12345682', 300, '2025-03-26', 'ORD000006'),
('P12345683', 250, '2025-03-27', 'ORD000007'),
('P12345684', 180, '2025-03-28', 'ORD000008'),
('P12345685', 270, '2025-03-29', 'ORD000009'),
('P12345686', 350, '2025-03-30', 'ORD000010'),
('P12345687', 190, '2025-03-31', 'ORD000011'),
('P12345688', 400, '2025-04-01', 'ORD000012'),
('P12345689', 230, '2025-04-02', 'ORD000013'),
('P12345690', 125, '2025-04-03', 'ORD000014'),
('P12345691', 325, '2025-04-04', 'ORD000015'),
('P12345692', 270, '2025-04-05', 'ORD000016'),
('P12345693', 100, '2025-04-06', 'ORD000017'),
('P12345694', 450, '2025-04-07', 'ORD000018'),
('P12345695', 130, '2025-04-08', 'ORD000019'),
('P12345696', 330, '2025-04-09', 'ORD000020'),
('P12345697', 250, '2025-04-10', 'ORD000021'),
('P12345698', 175, '2025-04-11', 'ORD000022'),
('P12345699', 300, '2025-04-12', 'ORD000023'),
('P12345700', 190, '2025-04-13', 'ORD000024'),
('P12345701', 220, '2025-04-14', 'ORD000025'),
('P12345702', 310, '2025-04-15', 'ORD000026'),
('P12345703', 410, '2025-04-16', 'ORD000027'),
('P12345704', 290, '2025-04-17', 'ORD000028'),
('P12345705', 360, '2025-04-18', 'ORD000029'),
('P12345706', 285, '2025-04-19', 'ORD000030'),
('P12345707', 110, '2025-04-20', 'ORD000031'),
('P12345708', 370, '2025-04-21', 'ORD000032'),
('P12345709', 150, '2025-04-22', 'ORD000033'),
('P12345710', 440, '2025-04-23', 'ORD000034'),
('P12345711', 160, '2025-04-24', 'ORD000035'),
('P12345712', 280, '2025-04-25', 'ORD000036'),
('P12345713', 230, '2025-04-26', 'ORD000037'),
('P12345714', 190, '2025-04-27', 'ORD000038'),
('P12345715', 345, '2025-04-28', 'ORD000039'),
('P12345716', 135, '2025-04-29', 'ORD000040');

SELECT count(*) FROM orders

--Records for Items table
INSERT INTO Items (productType, qtyInStock, itemName, item_ID, salePrice, order_ID) VALUES
('Contacts', 25, 'Contact Lens Solution', 'ITM000001', 14.99, 'ORD000001'),
('Glasses', 30, 'Anti-Glare Glasses', 'ITM000002', 45.50, 'ORD000002'),
('Eye Drops', 10, 'Lubricating Eye Drops', 'ITM000003', 8.99, 'ORD000003'),
('Glasses', 50, 'Eyeglass Cleaning Spray', 'ITM000004', 6.95, 'ORD000004'),
('Glasses', 120, 'Eyeglasses Case', 'ITM000005', 4.99, 'ORD000005'),
('Glasses', 60, 'Blue Light Glasses', 'ITM000006', 29.90, 'ORD000006'),
('Glasses', 15, 'Lens Cleaning Wipes', 'ITM000007', 3.75, 'ORD000007'),
('Accessories', 80, 'Prescription Lens Cloth', 'ITM000008', 2.99, 'ORD000008'),
('Glasses', 45, 'Reading Glasses', 'ITM000009', 19.99, 'ORD000009'),
('Sunglasses', 20, 'UV Blocking Sunglasses', 'ITM000010', 21.50, 'ORD000010'),
('Glasses', 40, 'Night Driving Glasses', 'ITM000011', 27.99, 'ORD000011'),
('Accessories', 75, 'Eye Mask for Sleeping', 'ITM000012', 9.95, 'ORD000012'),
('Accessories', 5, 'Magnifying Glass', 'ITM000013', 14.95, 'ORD000013'),
('Therapy', 22, 'Cold Eye Compress', 'ITM000014', 11.25, 'ORD000014'),
('Contacts', 35, 'Contact Lens Case', 'ITM000015', 2.99, 'ORD000015'),
('Contacts', 12, 'Scleral Lens Inserter', 'ITM000016', 4.50, 'ORD000016'),
('Therapy', 25, 'Dry Eye Relief Mask', 'ITM000017', 19.99, 'ORD000017'),
('Accessories', 70, 'Eyeglass Holder Strap', 'ITM000018', 5.99, 'ORD000018'),
('Glasses', 18, 'Anti-Fog Lens Spray', 'ITM000019', 7.50, 'ORD000019'),
('Glasses', 60, 'Optical Lens Cleaner Kit', 'ITM000020', 12.75, 'ORD000020'),
('Therapy', 28, 'Soft Eye Patches', 'ITM000021', 9.95, 'ORD000021'),
('Books', 8, 'Vision Exercise Book', 'ITM000022', 13.99, 'ORD000022'),
('Eye Drops', 16, 'Glaucoma Eye Drop Organizer', 'ITM000023', 15.95, 'ORD000023'),
('Glasses', 33, 'Kids Blue Light Glasses', 'ITM000024', 19.99, 'ORD000024'),
('Accessories', 95, 'Screen Magnifier', 'ITM000025', 22.45, 'ORD000025'),
('Accessories', 12, 'Stylish Eyewear Chain', 'ITM000026', 6.99, 'ORD000026'),
('Eye Drops', 14, 'Vision Lubricant Gel', 'ITM000027', 9.95, 'ORD000027'),
('Accessories', 19, 'Adjustable Glasses Screwdriver Kit', 'ITM000028', 4.49, 'ORD000028'),
('Accessories', 50, 'Nose Pads for Glasses', 'ITM000029', 3.50, 'ORD000029'),
('Accessories', 40, 'Eyeglass Frame Repair Kit', 'ITM000030', 6.25, 'ORD000030'),
('Sunglasses', 37, 'Sun Clip-ons for Prescription Glasses', 'ITM000031', 18.95, 'ORD000031'),
('Eye Drops', 22, 'Eye Allergy Relief Wipes', 'ITM000032', 7.99, 'ORD000032'),
('Accessories', 6, 'Desktop Magnifier Lamp', 'ITM000033', 59.99, 'ORD000033'),
('Glasses', 9, 'Bifocal Glasses', 'ITM000034', 89.99, 'ORD000034'),
('Sunglasses', 44, 'Polarized Clip-on Sunglasses', 'ITM000035', 12.95, 'ORD000035'),
('Accessories', 80, 'Lens Alignment Tool', 'ITM000036', 8.99, 'ORD000036'),
('Therapy', 17, 'Vision Therapy Flashcards', 'ITM000037', 14.99, 'ORD000037'),
('Contacts', 26, 'Contact Lens Suction Remover', 'ITM000038', 5.90, 'ORD000038'),
('Therapy', 33, 'Eye Cooling Gel Pads', 'ITM000039', 6.50, 'ORD000039'),
('Glasses', 14, 'Anti-Fatigue Reading Glasses', 'ITM000040', 29.99, 'ORD000040');


--Records for Includes table
INSERT INTO Includes (quantity, order_ID, item_ID) VALUES
(2450, 'ORD000001', 'ITM000001'),
(3100, 'ORD000002', 'ITM000002'),
(7890, 'ORD000003', 'ITM000003'),
(1200, 'ORD000004', 'ITM000004'),
(5625, 'ORD000005', 'ITM000005'),
(4030, 'ORD000006', 'ITM000006'),
(7140, 'ORD000007', 'ITM000007'),
(3220, 'ORD000008', 'ITM000008'),
(1500, 'ORD000009', 'ITM000009'),
(2980, 'ORD000010', 'ITM000010'),
(1350, 'ORD000011', 'ITM000011'),
(2600, 'ORD000012', 'ITM000012'),
(1175, 'ORD000013', 'ITM000013'),
(3890, 'ORD000014', 'ITM000014'),
(2950, 'ORD000015', 'ITM000015'),
(4485, 'ORD000016', 'ITM000016'),
(1680, 'ORD000017', 'ITM000017'),
(2540, 'ORD000018', 'ITM000018'),
(3790, 'ORD000019', 'ITM000019'),
(1450, 'ORD000020', 'ITM000020'),
(2860, 'ORD000021', 'ITM000021'),
(1950, 'ORD000022', 'ITM000022'),
(3670, 'ORD000023', 'ITM000023'),
(2340, 'ORD000024', 'ITM000024'),
(1230, 'ORD000025', 'ITM000025'),
(2690, 'ORD000026', 'ITM000026'),
(1100, 'ORD000027', 'ITM000027'),
(4930, 'ORD000028', 'ITM000028'),
(2430, 'ORD000029', 'ITM000029'),
(3520, 'ORD000030', 'ITM000030'),
(1760, 'ORD000031', 'ITM000031'),
(4380, 'ORD000032', 'ITM000032'),
(2890, 'ORD000033', 'ITM000033'),
(1900, 'ORD000034', 'ITM000034'),
(2985, 'ORD000035', 'ITM000035'),
(3560, 'ORD000036', 'ITM000036'),
(2695, 'ORD000037', 'ITM000037'),
(1810, 'ORD000038', 'ITM000038'),
(2970, 'ORD000039', 'ITM000039'),
(1240, 'ORD000040', 'ITM000040');


--Records for billPaymentPlaced table
INSERT INTO billPaymentPlaced (invoiceNumber, patient_ID, transactionDate, amount, paymentMethod) VALUES
('INV000001', 'PAT000001', '2024-01-15', 125.00, 'Credit Card'),
('INV000002', 'PAT000002', '2024-01-18', 230.75, 'Cash'),
('INV000003', 'PAT000003', '2024-01-22', 560.00, 'Debit Card'),
('INV000004', 'PAT000004', '2024-01-25', 89.50, 'Insurance'),
('INV000005', 'PAT000005', '2024-01-30', 345.60, 'Credit Card'),
('INV000006', 'PAT000006', '2024-02-03', 115.00, 'Cash'),
('INV000007', 'PAT000007', '2024-02-06', 280.00, 'Insurance'),
('INV000008', 'PAT000008', '2024-02-10', 149.99, 'Debit Card'),
('INV000009', 'PAT000009', '2024-02-14', 220.45, 'Credit Card'),
('INV000010', 'PAT000010', '2024-02-17', 175.75, 'Cash'),
('INV000011', 'PAT000011', '2024-02-20', 390.00, 'Credit Card'),
('INV000012', 'PAT000012', '2024-02-24', 95.00, 'Insurance'),
('INV000013', 'PAT000013', '2024-02-28', 130.99, 'Debit Card'),
('INV000014', 'PAT000014', '2024-03-03', 480.00, 'Credit Card'),
('INV000015', 'PAT000015', '2024-03-07', 160.50, 'Cash'),
('INV000016', 'PAT000016', '2024-03-11', 210.00, 'Credit Card'),
('INV000017', 'PAT000017', '2024-03-15', 305.40, 'Debit Card'),
('INV000018', 'PAT000018', '2024-03-20', 120.00, 'Insurance'),
('INV000019', 'PAT000019', '2024-03-23', 275.00, 'Credit Card'),
('INV000020', 'PAT000020', '2024-03-27', 445.25, 'Cash'),
('INV000021', 'PAT000021', '2024-04-01', 160.00, 'Credit Card'),
('INV000022', 'PAT000022', '2024-04-04', 298.80, 'Debit Card'),
('INV000023', 'PAT000023', '2024-04-08', 150.00, 'Insurance'),
('INV000024', 'PAT000024', '2024-04-11', 325.60, 'Credit Card'),
('INV000025', 'PAT000025', '2024-04-15', 200.00, 'Cash'),
('INV000026', 'PAT000026', '2024-04-18', 180.45, 'Debit Card'),
('INV000027', 'PAT000027', '2024-04-21', 260.00, 'Insurance'),
('INV000028', 'PAT000028', '2024-04-24', 350.00, 'Credit Card'),
('INV000029', 'PAT000029', '2024-04-28', 99.99, 'Cash'),
('INV000030', 'PAT000030', '2024-05-01', 410.75, 'Debit Card'),
('INV000031', 'PAT000031', '2024-05-04', 315.20, 'Credit Card'),
('INV000032', 'PAT000032', '2024-05-08', 285.00, 'Insurance'),
('INV000033', 'PAT000033', '2024-05-12', 210.45, 'Cash'),
('INV000034', 'PAT000034', '2024-05-15', 320.00, 'Debit Card'),
('INV000035', 'PAT000035', '2024-05-19', 275.30, 'Credit Card'),
('INV000036', 'PAT000036', '2024-05-23', 130.00, 'Insurance'),
('INV000037', 'PAT000037', '2024-05-27', 199.99, 'Credit Card'),
('INV000038', 'PAT000038', '2024-06-01', 289.75, 'Debit Card'),
('INV000039', 'PAT000039', '2024-06-05', 340.00, 'Cash'),
('INV000040', 'PAT000040', '2024-06-08', 460.00, 'Credit Card');



SELECT COUNT(*) FROM billPayment


--Business functions

--1: New Patient Registration(done)
INSERT INTO Patient (patient_ID, ssn, password, gender, dateOfBirth, medHistory, address, phoneNumber, email, name) 
VALUES ('P12345674', '123-45-6789', 'securepassword123', 'Male', '1985-06-15', 'No previous medical history', '123 Main St, Springfield, IL', '555-1234', 'johndoe@email.com', 'John Doe');

--2: Patient Login(done)
SELECT patient_ID 
FROM Patient 
WHERE email = 'johndoe@email.com' AND password = 'securepassword123';

--3: Make Appointment(done)
INSERT INTO AppointmentSchedule (appID, patient_ID, date, time) 
VALUES ('A1234567', 'P12345678', '2025-04-10', '10:00 AM');

--4: Update Patient Information(done)
UPDATE Patient 
SET password = 'newpassword123', gender = 'Male', dateOfBirth = '1985-06-15', 
    medHistory = 'No previous medical history', address = '123 Main St, Springfield, IL', phoneNumber = '555-5678', 
    email = 'newemail@email.com', name = 'John Doe', contactMethod = 'Phone'
WHERE ssn = '123-45-6789';

--5: Doctor Login(done)
SELECT docID, name, email, password
FROM DoctorWork 
WHERE email = 'asmith1@example.com' AND password = 'pass1234';

select * FROM results where docID = 'DOC000001'

select * from patient where patient_ID = 'P12345678'

--6: Record Eye Examination Results(done)
INSERT INTO Results (testResults, date, notes, prescription, docID, diagnosis, patient_ID, exam_ID) 
VALUES ('Eye pressure within normal range, no significant findings', '2025-04-10', 'Patient reported no discomfort during the exam. Eye health stable.', 'Eye drops prescribed for dryness', 'DOC000014', 'Normal eye health', 'P12345697', 'EX000041');

--7: Update Patient Medical History(done)
UPDATE Patient
SET medHistory = 'Patient has a history of high blood pressure and seasonal allergies.'
WHERE patient_ID = 'P12345678';

--8: Bill Payment Processing
INSERT INTO billPaymentPlaced (invoiceNumber, patient_ID, transactionDate, amount, paymentMethod) 
VALUES ('INV000041', 'P12345678', '2025-04-10', 250.00, 'Credit Card');


--9: Order Contact Lenses/Glasses(done)
    --Patient places order
    INSERT INTO Orders (patient_ID, totalAmount, orderDate, order_ID)
    VALUES ('P12345717', 180, '2025-04-30', 'ORD000041');
    --Orders is received from items
    INSERT INTO Items (productType, qtyInStock, itemName, item_ID, salePrice, order_ID)
    VALUES ('Eyewear', 50, 'Polarized Sunglasses', 'ITM000041', 45.99, 'ORD000041');




--10: Update Appointment Time(done)
UPDATE AppointmentSchedule
SET date = '2025-04-30', time = '14:00:00'
WHERE appID = 'A123456';
