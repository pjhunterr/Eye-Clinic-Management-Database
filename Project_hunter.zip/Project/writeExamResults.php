<?php
require_once('mysqli_connect.php');
session_start();
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Write Exam Results</title>
</head>
<body>
<?php
    if (isset($_SESSION['login_user'])) {
        $doctorID = mysqli_real_escape_string($dbc, $_SESSION['login_user']);

        // Query to fetch the doctor's past appointments (appointments that have already occurred)
        $query = "
            SELECT a.appID, p.name AS patientName, p.patient_ID, a.date
            FROM AppointmentSchedule a
            JOIN DoctorWork d ON a.appID = d.appID
            JOIN Patient p ON a.patient_ID = p.patient_ID
            WHERE d.docID = '$doctorID' AND a.date < CURDATE()
            ORDER BY a.date DESC, a.time DESC
        ";
        $response = mysqli_query($dbc, $query);

        if ($response && mysqli_num_rows($response) > 0) {
            echo "<h2>Select Appointment to Write Exam Results</h2>";
            echo "<form action='' method='POST'>";
            echo "<label for='appID'>Select Appointment:</label>";
            echo "<select name='appID' id='appID' required>";

            while ($row = mysqli_fetch_array($response, MYSQLI_ASSOC)) {
                echo "<option value='{$row['appID']}'>
                        {$row['patientName']} - {$row['appID']} - {$row['date']}
                      </option>";
            }

            echo "</select><br><br>";
            echo "<input type='submit' name='selectAppointment' value='Select Appointment'>";
            echo "</form>";
        } else {
            echo "<p>No past appointments assigned to you.</p>";
        }

        // Once an appointment is selected, the doctor can write exam results
        if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['selectAppointment'])) {
            $appID = $_POST['appID'];
            $query = "
                SELECT a.appID, p.name AS patientName, p.patient_ID
                FROM AppointmentSchedule a
                JOIN DoctorWork d ON a.appID = d.appID
                JOIN Patient p ON a.patient_ID = p.patient_ID
                WHERE a.appID = '$appID' AND d.docID = '$doctorID'
            ";
            $response = mysqli_query($dbc, $query);
            $row = mysqli_fetch_array($response, MYSQLI_ASSOC);

            if ($row) {
                $patientID = $row['patient_ID'];
                echo "<h2>Write Exam Results for {$row['patientName']}</h2>";
                echo "<form action='' method='POST'>";
                echo "<input type='hidden' name='appID' value='$appID'>";
                echo "<input type='hidden' name='patientID' value='$patientID'>";
                
                // Form fields for exam results
                echo "<label for='testResults'>Test Results:</label><br>";
                echo "<textarea name='testResults' id='testResults' rows='4' cols='50' required></textarea><br><br>";

                echo "<label for='notes'>Notes:</label><br>";
                echo "<textarea name='notes' id='notes' rows='4' cols='50' required></textarea><br><br>";

                echo "<label for='prescription'>Prescription:</label><br>";
                echo "<input type='text' name='prescription' id='prescription' required><br><br>";

                echo "<label for='diagnosis'>Diagnosis:</label><br>";
                echo "<input type='text' name='diagnosis' id='diagnosis' required><br><br>";

                echo "<input type='submit' name='submitResults' value='Submit Exam Results'>";
                echo "</form>";
            } else {
                echo "<p>Invalid appointment selected.</p>";
            }
        }

        // Insert exam results into the database
        if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submitResults'])) {
            $appID = $_POST['appID'];
            $patientID = $_POST['patientID'];
            $testResults = mysqli_real_escape_string($dbc, $_POST['testResults']);
            $notes = mysqli_real_escape_string($dbc, $_POST['notes']);
            $prescription = mysqli_real_escape_string($dbc, $_POST['prescription']);
            $diagnosis = mysqli_real_escape_string($dbc, $_POST['diagnosis']);
            $examID = uniqid('EXAM');  // Unique exam ID generation

            // Insert the exam results into the database
            $query = "
                INSERT INTO Results (testResults, date, notes, prescription, docID, diagnosis, patient_ID, exam_ID)
                VALUES ('$testResults', CURDATE(), '$notes', '$prescription', '$doctorID', '$diagnosis', '$patientID', '$examID')
            ";
            $response = mysqli_query($dbc, $query);

            if ($response) {
                echo "<p>Exam results have been successfully submitted.</p>";
            } else {
                echo "<p><b>Error:</b> Could not submit exam results. " . mysqli_error($dbc) . "</p>";
            }
        }

    } else {
        echo "<p><b>Error:</b> User not logged in.</p>";
    }

    echo "<p><a href='doctorWelcome.php'>Home</a></p>";
?>
</body>
</html>
