<?php
require_once('mysqli_connect.php');
session_start();
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Your Profile</title>
</head>
<body>
<?php
    if (isset($_SESSION['login_user'])) {
        $doctorID = mysqli_real_escape_string($dbc, $_SESSION['login_user']);

        // Query to fetch doctor data by docID
        $query = "SELECT * FROM DoctorWork WHERE docID = '$doctorID'";
        $response = mysqli_query($dbc, $query);

        if ($response && mysqli_num_rows($response) == 1) {
            $row = mysqli_fetch_array($response, MYSQLI_ASSOC);

            echo "<h2>Doctor Profile</h2>";
            echo "<p>Doctor ID: {$row['docID']}</p>";
            echo "<p>Name: {$row['name']}</p>";
            echo "<p>Email: {$row['email']}</p>";
            echo "<p>Appointed Appointment ID: {$row['appID']}</p>";
            echo "<p><a href='doctorWelcome.php'>Home</a></p>";
        } else {
            echo "<p><b>Error:</b> Invalid doctor ID or user not found.</p>";
        }
    } else {
        echo "<p><b>Error:</b> User not logged in.</p>";
    }
?>
</body>
</html>
