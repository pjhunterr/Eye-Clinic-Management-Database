<-- addCustomers.php ->
<!DOCTYPE html>
<!
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>                    
        <?php
        echo "<p><a href=\"index.php\">Home</a></p>";
        echo "</br>";
        echo "<form action=\"doctorAdded.php\" method=\"POST\">
            <b>Doctor Registration</b>
            <p>Doctor ID: <input type='text' name='docID' size='10' /></p>
            <p>Name: <input type='text' name='name' size='30' /></p>
            <p>Email: <input type='email' name='email' size='30' /></p>
            <p>Password: <input type='password' name='password' size='20' /></p>
            <p>Appointment ID: <input type='text' name='appID' size='10' /></p>
            <p><input type='submit' name='submit' value='Register' /></p>
        </form>";
        ?>
    </body>
</html>
