<?php
//Code for session.php
   require_once('mysqli_connect.php');
   session_start();
   
   $user_check = $_SESSION['login_user'];
   
   $ses_sql = mysqli_query($dbc,"select patient_ID from Patient where patient_ID = '".$user_check."' ");
   $docSes_sql = mysqli_query($dbc,"select docID from DoctorWork where docID= '".$user_check."' ");
   
   $row = mysqli_fetch_array($ses_sql,MYSQLI_ASSOC);
   $docRow  = mysqli_fetch_array($docSes_sql,MYSQLI_ASSOC);
   
   $login_session = $row['patient_ID'];
   $docLogin_session = $docRow['docID'];
   
   
   if(!isset($_SESSION['login_user'])){
      header("location:login.php");
   }
?>
